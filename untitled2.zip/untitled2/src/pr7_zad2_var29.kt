
fun main() {
    try {
        var n:Int;
        do {
            println("Введите год")
            n = readLine()!!.toInt()
        }while(n<1000||n>9999)
       var k=n%100
        if (!(n%100==0)&& k%4==0)
        {
            println("Год является високосным")
        }
        else
        {
            println("Год является високосным")
        }

    } catch(e:Exception){
        println("Введите число")
    }
}