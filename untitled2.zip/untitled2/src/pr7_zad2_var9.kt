
    fun main() {
        try {
            println("Введите первое число")
            var a = readLine()!!.toInt()
            println("Введите второе число")
            var b = readLine()!!.toInt()
            println("Введите третье число")
            var c = readLine()!!.toInt()
            when {
                (a >= 1) && (a <= 3) -> println(a)

            }
            when {
                (b >= 1) && (b <= 3) -> println(b)

            }
            when {
                (c >= 1) && (c <= 3) -> println(c)

            }
        } catch (e:Exception) {
            println("Введите символ")
        }
    }