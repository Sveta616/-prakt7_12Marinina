import kotlin.math.pow
import kotlin.math.abs
fun main() {
    try {

        val x=-2/3.toDouble()
        var z1=5*(x.pow(3))+ 70*(x.pow(2))+14* x
      var  z2=(abs( 5*x+70)*x+14)*x
            println(z1)
            println(z2)
when
{
    (z1==z2)->println("равны")
    else->println("не равны")
}
          }
    catch(e:Exception)
    {
        println("Введите символ")
    }

}