fun main() {
    try {
       var a:Double;
        var b:Double;
        var x:Double;
        var y:Double;
        var z:Double;
        do{
            println("Введите ширину отверстия")
           a= readLine()!!.toDouble()
            println("Введите длину отверстия")
            b= readLine()!!.toDouble()
            println("Введите длину кирпича")
            x= readLine()!!.toDouble()
            println("Введите высоту кирпича")
            y= readLine()!!.toDouble()
            println("Введите ширину кирпича")
            z= readLine()!!.toDouble()

        }while(a<=0||b<=0||x<=0 || y<=0 || z<=0)
        when
        {
            (a>x && b>y) || (a>y && b>z) || (a>z && b>x)->println("Кирпич проходит")
            else->println("Кирпич не проходит")
        }
    }
    catch (e:Exception)
    {
        print("Введите верное число")

    }    }