fun main() {
    try {
    println("Введите член прогресии")
    var a = readLine()!!.toDouble()
    println("Введите знаменатель")
    var b= readLine()!!.toInt()
    println("Введите номер с которого нужно начать")
    var k = readLine()!!.toInt()
    println("Введите номер до которого нужно выполнить")
    var p = readLine()!!.toDouble()
    if (k>0 && p>k)
    {
        var sum=0.toDouble()
        var c=1;

    while(c<k)
    {
        a=a*b;
        c=c+1;
    }
   while(c<=p)
   {
       sum=sum+a
       a=a*b
       c=c+1
   }
        println("Сумма=$sum")
    }
    else println("Попробуйте ещё раз, ошибка")
    }
    catch(e:Exception)
    {
        println("Введите символ")
    }

}
