import kotlin.math.abs
import kotlin.math.pow;
import kotlin.math.log10;
fun main() {
    try {
        println("Введите а")
        var a= readLine()!!.toDouble()
        println("Введите b")
        var b= readLine()!!.toDouble()
        println("Введите c")
        var c= readLine()!!.toDouble()
        println("Введите n")
        var n= readLine()!!.toDouble()
        println("Введите d")
        var d= readLine()!!.toDouble()
        var ch=0.25*(a-b)
        var ch1=abs(b)
        var zn=c-d
        var zn1=10.0.pow(n+3)
        var zn2=zn1+(log10(b)/zn)
        var ch2=ch1/zn2
        var ch6=(1/8)-ch2
        var ch7=ch/ch6

        when
        {
            (ch6>0)->println("Ответ $ch7")
          else->println("Знаменатель должен быть больше нуля")
        }


    }
        catch(e:Exception)
        {
            println("Введите символ")
        }

}